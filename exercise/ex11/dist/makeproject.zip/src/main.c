#include <stdio.h>
#include "helper.h"

int main() {
    // Call the function from helper.c to print the message
    print_help_message();

    return 0;
}