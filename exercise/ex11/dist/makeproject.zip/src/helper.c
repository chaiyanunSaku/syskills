#include <stdio.h>
#include "helper.h"

void print_help_message() {
    printf("I'm here to help\n");
}