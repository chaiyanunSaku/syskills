#ifndef HELPER_H
#define HELPER_H

// Function declaration
void print_help_message();

#endif // HELPER_H